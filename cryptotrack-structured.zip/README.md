# CryptoTrack

React + TypeScript crypto tracking dashboard based on the original single-file `crypto-tracker.jsx`.

## Run

```bash
npm install
npm run dev
```

## Structure

- `src/components/` reusable UI components
- `src/pages/` screen-level views
- `src/hooks/` reusable state/data logic
- `src/services/` CoinGecko API calls
- `src/utils/` formatting and localStorage helpers
- `src/constants/` app constants and themes
- `src/types/` TypeScript data models
- `src/styles/` global CSS

## Important

The original authentication is client-side/demo authentication using `localStorage`. It is not secure production authentication. For a real account system, replace it with a backend and password hashing/session or token authentication.
