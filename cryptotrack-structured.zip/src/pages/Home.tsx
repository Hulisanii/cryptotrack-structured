import type { Coin, ThemeName } from "../types";
import CoinCard from "../components/crypto/CoinCard";
import CoinTicker from "../components/crypto/CoinTicker";
import SearchBar from "../components/crypto/SearchBar";
import StatusBar from "../components/crypto/StatusBar";
import { EmptyState } from "../components/portfolio/PortfolioPanel";
import { THEMES } from "../constants/app";

interface Props {
  coins: Coin[];
  search: string;
  setSearch: (value: string) => void;
  loading: boolean;
  error: string | null;
  lastUpdated: number | null;
  watchlist: string[];
  theme: ThemeName;
  onOpen: (coin: Coin) => void;
  onToggleWatch: (id: string) => void;
}

export default function Home({ coins, search, setSearch, loading, error, lastUpdated, watchlist, theme, onOpen, onToggleWatch }: Props) {
  const filtered = coins.filter((coin) => coin.name.toLowerCase().includes(search.toLowerCase()) || coin.symbol.toLowerCase().includes(search.toLowerCase()));
  const tokens = THEMES[theme];
  return <>
    <CoinTicker coins={coins} onSelect={onOpen} />
    <StatusBar lastUpdated={lastUpdated} coinCount={coins.length} />
    <SearchBar value={search} onChange={setSearch} />
    {error && <div className="error-bar">⚠️ {error}</div>}
    {loading ? <div className="loading-wrap"><div className="loading-icon">📡</div><div>Fetching live prices…</div><small>via CoinGecko API</small></div> : filtered.length === 0 ? <EmptyState icon="🔍" title={`No results for "${search}"`} /> : filtered.map((coin, index) => <CoinCard key={coin.id} coin={coin} rank={index + 1} watched={watchlist.includes(coin.id)} theme={theme} onOpen={onOpen} onToggleWatch={onToggleWatch} />)}
    <span className="sr-only">Accent color: {tokens.accent}</span>
  </>;
}
