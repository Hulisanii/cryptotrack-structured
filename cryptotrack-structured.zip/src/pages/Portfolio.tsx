import PortfolioPanel from "../components/portfolio/PortfolioPanel";
import type { AddPortfolioForm, Coin, PortfolioStats, ThemeName } from "../types";

interface Props {
  coins: Coin[];
  stats: PortfolioStats[];
  form: AddPortfolioForm;
  setForm: (value: AddPortfolioForm) => void;
  totalValue: number;
  totalCost: number;
  totalPnl: number;
  onAdd: () => void;
  onRemove: (id: number) => void;
  theme: ThemeName;
}

export default function Portfolio({ ...props }: Props) { return <PortfolioPanel {...props} />; }
