import SettingsPanel from "../components/settings/SettingsPanel";
import type { NotificationSettings, ThemeName, User } from "../types";

interface Props { user: User | null; theme: ThemeName; notifications: NotificationSettings; setTheme: (theme: ThemeName) => void; setNotifications: (settings: NotificationSettings) => void; onLogout: () => void; }
export default function Settings(props: Props) { return <SettingsPanel {...props} />; }
