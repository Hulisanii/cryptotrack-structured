import type { Coin, ThemeName } from "../types";
import CoinCard from "../components/crypto/CoinCard";
import { EmptyState } from "../components/portfolio/PortfolioPanel";

export default function Watchlist({ coins, watchlist, theme, onOpen, onToggleWatch }: { coins: Coin[]; watchlist: string[]; theme: ThemeName; onOpen: (coin: Coin) => void; onToggleWatch: (id: string) => void }) {
  const watchedCoins = coins.filter((coin) => watchlist.includes(coin.id));
  if (!watchedCoins.length) return <EmptyState icon="⭐" title="Your watchlist is empty" subtitle="Tap ☆ Watch on any coin to add it here." />;
  return <>{watchedCoins.map((coin) => <CoinCard key={coin.id} coin={coin} watched theme={theme} onOpen={onOpen} onToggleWatch={onToggleWatch} />)}</>;
}
