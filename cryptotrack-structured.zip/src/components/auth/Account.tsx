import type { AuthForm, AuthMode } from "../../types";

type Props = {
  mode: Extract<AuthMode, "landing" | "login" | "signup">;
  form: AuthForm;
  error: string;
  onModeChange: (mode: Extract<AuthMode, "landing" | "login" | "signup">) => void;
  onFormChange: (form: AuthForm) => void;
  onSignup: () => void;
  onLogin: () => void;
  onGuest: () => void;
  onClearError: () => void;
};

export default function Account({
  mode,
  form,
  error,
  onModeChange,
  onFormChange,
  onSignup,
  onLogin,
  onGuest,
  onClearError,
}: Props) {
  const update = (key: keyof AuthForm, value: string) => onFormChange({ ...form, [key]: value });

  if (mode === "landing") {
    return (
      <main className="auth-wrap">
        <section className="auth-card">
          <Logo />
          <h1 className="auth-title">Live crypto, your way.</h1>
          <p className="auth-sub">Track prices, manage your portfolio, and stay ahead of the market — all in one place.</p>
          <div className="auth-actions">
            <button className="btn btn-accent" onClick={() => onModeChange("signup")}>Create Account</button>
            <button className="btn btn-outline" onClick={() => onModeChange("login")}>Sign In</button>
            <button className="btn btn-ghost" onClick={onGuest}>Continue as Guest →</button>
          </div>
          <div className="auth-features">
            <span>📈 Live Prices</span>
            <span>📊 Portfolio</span>
            <span>⭐ Watchlist</span>
          </div>
        </section>
      </main>
    );
  }

  const signup = mode === "signup";
  return (
    <main className="auth-wrap">
      <section className="auth-card">
        <Logo />
        <h1 className="auth-title">{signup ? "Create account" : "Welcome back"}</h1>
        <p className="auth-sub">{signup ? "Start tracking the market today." : "Sign in to your account."}</p>
        {error && <div className="auth-error">{error}</div>}
        {signup && <input className="text-input" placeholder="Username" value={form.username} onChange={(e) => update("username", e.target.value)} />}
        <input className="text-input" placeholder="Email" type="email" value={form.email} onChange={(e) => update("email", e.target.value)} />
        <input className="text-input" placeholder={signup ? "Password (min 6 chars)" : "Password"} type="password" value={form.password} onChange={(e) => update("password", e.target.value)} />
        <button className="btn btn-accent" onClick={signup ? onSignup : onLogin}>{signup ? "Create Account" : "Sign In"}</button>
        <button className="btn btn-outline" onClick={() => { onModeChange(signup ? "login" : "signup"); onClearError(); }}>
          {signup ? "Already have an account? Sign In" : "New here? Create Account"}
        </button>
        <button className="btn btn-ghost" onClick={() => { onModeChange("landing"); onClearError(); }}>← Back</button>
      </section>
    </main>
  );
}

function Logo() {
  return <div className="logo"><div className="logo-icon">₿</div><span className="logo-text">CryptoTrack</span></div>;
}
