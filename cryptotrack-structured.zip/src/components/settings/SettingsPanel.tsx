import type { ReactNode } from "react";
import type { NotificationSettings, ThemeName, User } from "../../types";

interface Props {
  user: User | null;
  theme: ThemeName;
  notifications: NotificationSettings;
  setTheme: (theme: ThemeName) => void;
  setNotifications: (settings: NotificationSettings) => void;
  onLogout: () => void;
}

export default function SettingsPanel({ user, theme, notifications, setTheme, setNotifications, onLogout }: Props) {
  return (
    <>
      <div className="profile-card"><div className="profile-avatar">{user?.username?.[0]?.toUpperCase() || "G"}</div><div><div className="profile-name">{user?.username || "Guest"}</div><div className="profile-email">{user?.guest ? "Browsing as guest" : user?.email}</div></div></div>
      <section className="settings-section"><div className="settings-title">Appearance</div><div className="settings-card"><SettingRow title="Dark Mode" subtitle="Switch between dark and light themes"><button className={`toggle ${theme === "dark" ? "on" : ""}`} onClick={() => setTheme(theme === "dark" ? "light" : "dark")}><span /></button></SettingRow><SettingRow last title="Currency" subtitle="All prices shown in USD"><strong>USD</strong></SettingRow></div></section>
      <section className="settings-section"><div className="settings-title">Notifications</div><div className="settings-card"><SettingRow title="Price Alerts" subtitle="Significant price movements"><button className={`toggle ${notifications.price ? "on" : ""}`} onClick={() => setNotifications({ ...notifications, price: !notifications.price })}><span /></button></SettingRow><SettingRow last title="Market News" subtitle="Breaking crypto news"><button className={`toggle ${notifications.news ? "on" : ""}`} onClick={() => setNotifications({ ...notifications, news: !notifications.news })}><span /></button></SettingRow></div></section>
      <section className="settings-section"><div className="settings-title">Data</div><div className="settings-card"><SettingRow title="Data Source" subtitle="Live market data provider"><strong>CoinGecko</strong></SettingRow><SettingRow last title="Refresh Rate" subtitle="Auto-refresh interval"><strong>30s</strong></SettingRow></div></section>
      <section className="settings-section"><div className="settings-title">About</div><div className="settings-card"><SettingRow title="Version"><strong>1.0.0</strong></SettingRow><SettingRow last title="Stack" subtitle="React · TypeScript · Recharts"><span>⚛️</span></SettingRow></div></section>
      <div className="logout-wrap"><button className="logout-btn" onClick={onLogout}>{user?.guest ? "Exit Guest Mode" : "Sign Out"}</button></div>
    </>
  );
}

function SettingRow({ title, subtitle, last, children }: { title: string; subtitle?: string; last?: boolean; children: ReactNode }) {
  return <div className={`setting-row ${last ? "last" : ""}`}><div><div className="setting-row-title">{title}</div>{subtitle && <div className="setting-row-sub">{subtitle}</div>}</div>{children}</div>;
}
