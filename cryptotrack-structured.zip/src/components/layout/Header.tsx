import type { AppTab, User } from "../../types";

interface Props {
  tab: AppTab;
  user: User | null;
  onRefresh: () => void;
  onOpenSettings: () => void;
}

export default function Header({ tab, user, onRefresh, onOpenSettings }: Props) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "morning" : hour < 18 ? "afternoon" : "evening";
  const heading = tab === "home" ? user?.username || "Trader" : tab === "watchlist" ? "Watchlist" : tab === "portfolio" ? "Portfolio" : "Settings";
  const prefix = tab === "home" ? `Good ${greeting},` : tab === "watchlist" ? "⭐ Your" : tab === "portfolio" ? "📊 Your" : "⚙️";

  return (
    <header className="header">
      <div className="header-left">
        <span className="header-greet">{prefix}</span>
        <span className="header-title">{heading}</span>
      </div>
      <div className="header-right">
        {tab === "home" && <button className="icon-button" onClick={onRefresh} title="Refresh">↻</button>}
        <button className="avatar-btn" onClick={onOpenSettings}>{user?.username?.[0]?.toUpperCase() || "G"}</button>
      </div>
    </header>
  );
}
