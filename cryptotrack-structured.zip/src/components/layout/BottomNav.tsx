import type { AppTab } from "../../types";

const items: { key: AppTab; icon: string; label: string }[] = [
  { key: "home", icon: "🏠", label: "Home" },
  { key: "watchlist", icon: "⭐", label: "Watchlist" },
  { key: "portfolio", icon: "📊", label: "Portfolio" },
  { key: "settings", icon: "⚙️", label: "Settings" },
];

export default function BottomNav({ tab, onChange }: { tab: AppTab; onChange: (tab: AppTab) => void }) {
  return (
    <nav className="bottom-nav">
      {items.map((item) => (
        <button key={item.key} className={`nav-item ${tab === item.key ? "active" : ""}`} onClick={() => onChange(item.key)}>
          <span className="nav-icon">{item.icon}</span>
          <span className="nav-label">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
