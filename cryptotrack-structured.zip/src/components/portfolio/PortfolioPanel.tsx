import type { AddPortfolioForm, Coin, PortfolioStats, ThemeName } from "../../types";
import { formatCurrency } from "../../utils/format";
import { THEMES } from "../../constants/app";

interface Props {
  coins: Coin[];
  stats: PortfolioStats[];
  form: AddPortfolioForm;
  setForm: (value: AddPortfolioForm) => void;
  totalValue: number;
  totalCost: number;
  totalPnl: number;
  onAdd: () => void;
  onRemove: (id: number) => void;
  theme: ThemeName;
}

export default function PortfolioPanel({ coins, stats, form, setForm, totalValue, totalCost, totalPnl, onAdd, onRemove, theme }: Props) {
  const tokens = THEMES[theme];
  const totalPct = totalCost > 0 ? (totalPnl / totalCost) * 100 : 0;
  return (
    <>
      <div className="portfolio-total"><div className="portfolio-label">Total Portfolio Value</div><div className="portfolio-value">{formatCurrency(totalValue)}</div><div className="portfolio-pnl">P&L: {totalPnl >= 0 ? "+" : ""}{formatCurrency(totalPnl)} ({totalPct.toFixed(2)}%)</div></div>
      <div className="portfolio-add-card">
        <div className="portfolio-add-title">➕ Add Position</div>
        <select className="portfolio-select" value={form.coinId} onChange={(e) => setForm({ ...form, coinId: e.target.value })}><option value="">Select coin…</option>{coins.map((coin) => <option key={coin.id} value={coin.id}>{coin.name} ({coin.symbol.toUpperCase()})</option>)}</select>
        <div className="portfolio-input-row"><input className="portfolio-input" placeholder="Amount" type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /><input className="portfolio-input" placeholder="Buy price ($)" type="number" value={form.buyPrice} onChange={(e) => setForm({ ...form, buyPrice: e.target.value })} /></div>
        <button className="portfolio-add-btn" onClick={onAdd}>Add to Portfolio</button>
      </div>
      {stats.length === 0 ? <EmptyState icon="📊" title="No positions yet" subtitle="Add your first position above." /> : stats.map((entry) => (
        <div key={entry.id} className="portfolio-entry-card">
          <div className="portfolio-entry-top">{entry.coin && <img src={entry.coin.image} alt={entry.coin.name} width={36} height={36} />}
            <div><div className="portfolio-entry-name">{entry.coin?.name || entry.coinId}</div><div className="portfolio-entry-sub">{entry.amount} {entry.coin?.symbol?.toUpperCase()}</div></div>
            <div className="portfolio-entry-right"><div className="portfolio-entry-value">{formatCurrency(entry.value)}</div><div style={{ color: entry.pnl >= 0 ? tokens.accent : tokens.neg }} className="portfolio-entry-change">{entry.pnl >= 0 ? "+" : ""}{formatCurrency(entry.pnl)} ({entry.pnlPct.toFixed(2)}%)</div></div>
          </div>
          <div className="portfolio-entry-footer"><span>Avg cost: {formatCurrency(entry.buyPrice)} · Now: {formatCurrency(entry.currentPrice)}</span><button className="remove-btn" onClick={() => onRemove(entry.id)}>Remove</button></div>
        </div>
      ))}
    </>
  );
}

export function EmptyState({ icon, title, subtitle }: { icon: string; title: string; subtitle?: string }) {
  return <div className="empty-state"><div className="empty-icon">{icon}</div><div className="empty-title">{title}</div>{subtitle && <div className="empty-subtitle">{subtitle}</div>}</div>;
}
