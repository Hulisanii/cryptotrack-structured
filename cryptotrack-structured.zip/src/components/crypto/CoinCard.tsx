import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { COIN_COLORS, THEMES } from "../../constants/app";
import type { Coin } from "../../types";
import { formatCurrency, formatPercent } from "../../utils/format";

interface Props {
  coin: Coin;
  rank?: number;
  watched: boolean;
  theme: "dark" | "light";
  onOpen: (coin: Coin) => void;
  onToggleWatch: (id: string) => void;
}

export default function CoinCard({ coin, rank, watched, theme, onOpen, onToggleWatch }: Props) {
  const tokens = THEMES[theme];
  const change = coin.price_change_percentage_24h ?? 0;
  const isUp = change >= 0;
  const sparkData = (coin.sparkline_in_7d?.price || []).slice(-24).map((price, index) => ({ i: index, p: price }));
  const gradientId = `sg-${coin.id}`;

  return (
    <article className="coin-card" onClick={() => onOpen(coin)}>
      <div className="coin-card-top">
        <div className="coin-image-wrap">
          <img className="coin-img" src={coin.image} alt={coin.name} onError={(e) => { e.currentTarget.style.display = "none"; }} />
          {rank !== undefined && <span className="coin-rank">{rank}</span>}
        </div>
        <div>
          <div className="coin-name">{coin.name}</div>
          <div className="coin-symbol">{coin.symbol}</div>
        </div>
        <div className="coin-right">
          <div className="coin-price">{formatCurrency(coin.current_price)}</div>
          <div className="coin-change" style={{ color: isUp ? tokens.accent : tokens.neg }}>{isUp ? "▲" : "▼"} {formatPercent(Math.abs(change))}</div>
        </div>
      </div>
      {sparkData.length > 0 && (
        <div className="sparkline-wrap">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sparkData}>
              <defs>
                <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={isUp ? tokens.accent : tokens.neg} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={isUp ? tokens.accent : tokens.neg} stopOpacity={0} />
                </linearGradient>
              </defs>
              <Area type="monotone" dataKey="p" stroke={isUp ? tokens.accent : tokens.neg} fill={`url(#${gradientId})`} strokeWidth={1.5} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}
      <div className="coin-card-footer">
        <span className="coin-mcap">MCap: {formatCurrency(coin.market_cap)}</span>
        <button className={`watch-btn ${watched ? "active" : ""}`} onClick={(e) => { e.stopPropagation(); onToggleWatch(coin.id); }}>
          {watched ? "★ Watching" : "☆ Watch"}
        </button>
      </div>
      {COIN_COLORS[coin.id] && <span className="sr-only">{COIN_COLORS[coin.id]}</span>}
    </article>
  );
}
