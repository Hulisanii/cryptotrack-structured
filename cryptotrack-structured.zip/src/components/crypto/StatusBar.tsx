import { timeAgo } from "../../utils/format";

export default function StatusBar({ lastUpdated, coinCount }: { lastUpdated: number | null; coinCount: number }) {
  const live = !!lastUpdated && Date.now() - lastUpdated < 45_000;
  return (
    <div className="status-bar">
      <span className="status-text"><span className={`status-dot ${live ? "live" : "offline"}`} />{lastUpdated ? `Updated ${timeAgo(lastUpdated)}` : "Connecting…"}</span>
      <span className="status-text">{coinCount} coins • Auto-refresh 30s</span>
    </div>
  );
}
