import { useEffect, useState } from "react";
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { THEMES } from "../../constants/app";
import { fetchCoinHistory } from "../../services/cryptoApi";
import type { ChartPoint, Coin, ThemeName } from "../../types";
import { formatCurrency, formatPercent, formatSupply } from "../../utils/format";

interface Props {
  coin: Coin | null;
  theme: ThemeName;
  watched: boolean;
  onClose: () => void;
  onToggleWatch: (id: string) => void;
}

export default function CoinDetailModal({ coin, theme, watched, onClose, onToggleWatch }: Props) {
  const [history, setHistory] = useState<ChartPoint[]>([]);
  const [loading, setLoading] = useState(false);
  const [range, setRange] = useState(1);
  const tokens = THEMES[theme];

  useEffect(() => {
    if (!coin) return;
    setLoading(true);
    fetchCoinHistory(coin.id, range).then(setHistory).catch(() => setHistory([])).finally(() => setLoading(false));
  }, [coin, range]);

  if (!coin) return null;
  const isUp = (coin.price_change_percentage_24h ?? 0) >= 0;
  const ranges = [{ label: "24H", days: 1 }, { label: "7D", days: 7 }, { label: "30D", days: 30 }, { label: "90D", days: 90 }];
  const stats = [
    ["Market Cap", formatCurrency(coin.market_cap)],
    ["24h Volume", formatCurrency(coin.total_volume)],
    ["24h High", formatCurrency(coin.high_24h)],
    ["24h Low", formatCurrency(coin.low_24h)],
    ["Circulating Supply", formatSupply(coin.circulating_supply)],
    ["All-Time High", formatCurrency(coin.ath)],
  ];

  return (
    <div className="modal-overlay" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="modal-card">
        <div className="modal-handle" />
        <div className="modal-header">
          <div className="modal-coin">
            <img src={coin.image} alt={coin.name} width={32} height={32} />
            <div><div className="modal-coin-name">{coin.name}</div><div className="modal-symbol">{coin.symbol}</div></div>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-price-block">
          <div className="modal-price">{formatCurrency(coin.current_price)}</div>
          <div className="modal-change" style={{ color: isUp ? tokens.accent : tokens.neg }}>{isUp ? "▲" : "▼"} {formatPercent(Math.abs(coin.price_change_percentage_24h ?? 0))} (24h)</div>
        </div>
        <div className="range-row">
          {ranges.map((item) => <button key={item.days} className={`range-btn ${range === item.days ? "active" : ""}`} onClick={() => setRange(item.days)}>{item.label}</button>)}
        </div>
        <div className="chart-wrap">
          {loading ? <div className="chart-message">Loading chart…</div> : history.length ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={history}>
                <defs><linearGradient id="detailGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor={isUp ? tokens.accent : tokens.neg} stopOpacity={0.35} /><stop offset="95%" stopColor={isUp ? tokens.accent : tokens.neg} stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" stroke={tokens.border} />
                <XAxis dataKey="time" tick={{ fontSize: 10, fill: tokens.muted }} interval="preserveStartEnd" />
                <YAxis tick={{ fontSize: 10, fill: tokens.muted }} tickFormatter={(value: number) => `$${value >= 1000 ? `${(value / 1000).toFixed(1)}k` : value.toFixed(2)}`} width={60} />
                <Tooltip contentStyle={{ background: tokens.card, border: `1px solid ${tokens.border}`, borderRadius: 10, color: tokens.text, fontSize: 12 }} formatter={(value) => [formatCurrency(Number(value)), "Price"]} />
                <Area type="monotone" dataKey="price" stroke={isUp ? tokens.accent : tokens.neg} fill="url(#detailGrad)" strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          ) : <div className="chart-message">No chart data available.</div>}
        </div>
        <div className="modal-stats">{stats.map(([label, value]) => <div className="modal-stat-card" key={label}><div className="modal-stat-label">{label}</div><div className="modal-stat-value">{value}</div></div>)}</div>
        <div className="modal-action"><button className={`btn ${watched ? "btn-watch-active" : "btn-outline"}`} onClick={() => onToggleWatch(coin.id)}>{watched ? "★ Remove from Watchlist" : "☆ Add to Watchlist"}</button></div>
      </section>
    </div>
  );
}
