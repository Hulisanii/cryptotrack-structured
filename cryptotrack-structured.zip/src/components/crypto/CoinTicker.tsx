import { COIN_COLORS } from "../../constants/app";
import type { Coin } from "../../types";

export default function CoinTicker({ coins, onSelect }: { coins: Coin[]; onSelect: (coin: Coin) => void }) {
  return (
    <div className="ticker-wrap">
      {coins.slice(0, 10).map((coin) => {
        const accent = COIN_COLORS[coin.id] || "#333";
        return (
          <button key={coin.id} className="ticker-coin" onClick={() => onSelect(coin)}>
            <div className="ticker-icon" style={{ background: `${accent}22`, borderColor: accent }}>
              <img src={coin.image} alt={coin.symbol} width={28} height={28} onError={(e) => { e.currentTarget.style.display = "none"; }} />
            </div>
            <span className="ticker-label">{coin.symbol.toUpperCase()}</span>
          </button>
        );
      })}
    </div>
  );
}
