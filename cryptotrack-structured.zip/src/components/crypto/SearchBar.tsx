export default function SearchBar({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return (
    <div className="search-wrap">
      <div className="search-inner">
        <span className="search-icon">🔍</span>
        <input className="search-input" placeholder="Search coins…" value={value} onChange={(e) => onChange(e.target.value)} />
      </div>
    </div>
  );
}
