import type { ThemeName, ThemeTokens } from "../types";

export const COINGECKO_BASE = import.meta.env.VITE_COINGECKO_BASE || "https://api.coingecko.com/api/v3";
export const TOP_COINS = [
  "bitcoin",
  "ethereum",
  "tether",
  "binancecoin",
  "bitcoin-cash",
  "raydium",
  "avalanche-2",
  "polkadot",
  "dogecoin",
  "stellar",
];
export const REFRESH_INTERVAL = 30_000;

export const COIN_COLORS: Record<string, string> = {
  bitcoin: "#F7931A",
  ethereum: "#627EEA",
  tether: "#26A17B",
  binancecoin: "#F3BA2F",
  "bitcoin-cash": "#8DC351",
  raydium: "#E84142",
  "avalanche-2": "#E84142",
  polkadot: "#E6007A",
  dogecoin: "#C2A633",
  stellar: "#7D00FF",
};

export const THEMES: Record<ThemeName, ThemeTokens> = {
  dark: {
    bg: "#070B18",
    surface: "#0F1629",
    card: "#141C35",
    border: "#1E2A4A",
    text: "#F0F4FF",
    muted: "#6B7DB3",
    accent: "#00D4AA",
    neg: "#FF4F6D",
    nav: "#0A1020",
  },
  light: {
    bg: "#F4F6FA",
    surface: "#FFFFFF",
    card: "#FFFFFF",
    border: "#E2E8F0",
    text: "#0A1020",
    muted: "#64748B",
    accent: "#00B894",
    neg: "#E53E5A",
    nav: "#FFFFFF",
  },
};
