export type AuthMode = "landing" | "login" | "signup" | "app";
export type AppTab = "home" | "watchlist" | "portfolio" | "settings";
export type ThemeName = "dark" | "light";

export interface User {
  username: string;
  email: string;
  createdAt: number;
  guest?: boolean;
}

export interface AuthForm {
  username: string;
  email: string;
  password: string;
}

export interface Coin {
  id: string;
  name: string;
  symbol: string;
  image: string;
  current_price: number;
  market_cap: number | null;
  total_volume: number | null;
  high_24h: number | null;
  low_24h: number | null;
  circulating_supply: number | null;
  ath: number | null;
  price_change_percentage_1h_in_currency?: number | null;
  price_change_percentage_24h?: number | null;
  price_change_percentage_7d_in_currency?: number | null;
  sparkline_in_7d?: { price: number[] };
}

export interface PortfolioEntry {
  id: number;
  coinId: string;
  amount: number;
  buyPrice: number;
}

export interface PortfolioStats extends PortfolioEntry {
  coin?: Coin;
  currentPrice: number;
  value: number;
  cost: number;
  pnl: number;
  pnlPct: number;
}

export interface ChartPoint {
  time: string;
  price: number;
}

export interface NotificationSettings {
  price: boolean;
  news: boolean;
}

export interface ThemeTokens {
  bg: string;
  surface: string;
  card: string;
  border: string;
  text: string;
  muted: string;
  accent: string;
  neg: string;
  nav: string;
}

export interface AddPortfolioForm {
  coinId: string;
  amount: string;
  buyPrice: string;
}
