import { COINGECKO_BASE, TOP_COINS } from "../constants/app";
import type { ChartPoint, Coin } from "../types";

async function parseResponse<T>(response: Response): Promise<T> {
  if (!response.ok) throw new Error(`API error ${response.status}`);
  return response.json() as Promise<T>;
}

export async function fetchTopCoins(): Promise<Coin[]> {
  const response = await fetch(
    `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${TOP_COINS.join(",")}&order=market_cap_desc&per_page=20&page=1&sparkline=true&price_change_percentage=1h,24h,7d`,
  );
  return parseResponse<Coin[]>(response);
}

export async function fetchCoinHistory(coinId: string, days: number): Promise<ChartPoint[]> {
  const response = await fetch(
    `${COINGECKO_BASE}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`,
  );
  const data = await parseResponse<{ prices?: [number, number][] }>(response);
  return (data.prices || []).map(([timestamp, price]) => ({
    time: new Date(timestamp).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    }),
    price,
  }));
}
