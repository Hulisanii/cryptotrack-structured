import { useState, type CSSProperties } from "react";
import Account from "./components/auth/Account";
import BottomNav from "./components/layout/BottomNav";
import Header from "./components/layout/Header";
import CoinDetailModal from "./components/crypto/CoinDetailModal";
import Home from "./pages/Home";
import Watchlist from "./pages/Watchlist";
import Portfolio from "./pages/Portfolio";
import Settings from "./pages/Settings";
import { THEMES } from "./constants/app";
import { useAuth } from "./hooks/useAuth";
import { useCryptoData } from "./hooks/useCryptoData";
import { usePortfolio } from "./hooks/usePortfolio";
import { usePreferences } from "./hooks/usePreferences";
import { useWatchlist } from "./hooks/useWatchlist";
import type { AppTab, Coin } from "./types";

export default function App() {
  const auth = useAuth();
  const [tab, setTab] = useState<AppTab>("home");
  const [search, setSearch] = useState("");
  const [detail, setDetail] = useState<Coin | null>(null);
  const preferences = usePreferences();
  const crypto = useCryptoData(auth.authMode === "app");
  const watch = useWatchlist();
  const portfolio = usePortfolio(crypto.coins);
  const tokens = THEMES[preferences.theme];

  if (auth.authMode !== "app") {
    return <div className="app-root" style={{ "--bg": tokens.bg, "--surface": tokens.surface, "--card": tokens.card, "--border": tokens.border, "--text": tokens.text, "--muted": tokens.muted, "--accent": tokens.accent, "--neg": tokens.neg, "--nav": tokens.nav } as CSSProperties}><Account mode={auth.authMode} form={auth.authForm} error={auth.authError} onModeChange={auth.setAuthMode} onFormChange={auth.setAuthForm} onSignup={auth.signup} onLogin={auth.login} onGuest={auth.guestLogin} onClearError={auth.clearError} /></div>;
  }

  return (
    <div className="app-root" style={{ "--bg": tokens.bg, "--surface": tokens.surface, "--card": tokens.card, "--border": tokens.border, "--text": tokens.text, "--muted": tokens.muted, "--accent": tokens.accent, "--neg": tokens.neg, "--nav": tokens.nav } as CSSProperties}>
      <div className="app-wrap">
        <Header tab={tab} user={auth.user} onRefresh={crypto.refresh} onOpenSettings={() => setTab("settings")} />
        {tab === "home" && <Home coins={crypto.coins} search={search} setSearch={setSearch} loading={crypto.loading} error={crypto.error} lastUpdated={crypto.lastUpdated} watchlist={watch.watchlist} theme={preferences.theme} onOpen={setDetail} onToggleWatch={watch.toggleWatch} />}
        {tab === "watchlist" && <Watchlist coins={crypto.coins} watchlist={watch.watchlist} theme={preferences.theme} onOpen={setDetail} onToggleWatch={watch.toggleWatch} />}
        {tab === "portfolio" && <Portfolio coins={crypto.coins} stats={portfolio.stats} form={portfolio.form} setForm={portfolio.setForm} totalValue={portfolio.totalValue} totalCost={portfolio.totalCost} totalPnl={portfolio.totalPnl} onAdd={portfolio.addPosition} onRemove={portfolio.removePosition} theme={preferences.theme} />}
        {tab === "settings" && <Settings user={auth.user} theme={preferences.theme} notifications={preferences.notifications} setTheme={preferences.setTheme} setNotifications={preferences.setNotifications} onLogout={() => { auth.logout(); setTab("home"); }} />}
      </div>
      <BottomNav tab={tab} onChange={setTab} />
      <CoinDetailModal coin={detail} theme={preferences.theme} watched={detail ? watch.watchlist.includes(detail.id) : false} onClose={() => setDetail(null)} onToggleWatch={watch.toggleWatch} />
    </div>
  );
}
