import { useEffect, useState } from "react";
import { loadLocal, saveLocal } from "../utils/storage";

const WATCHLIST_KEY = "crypto_watchlist";

export function useWatchlist() {
  const [watchlist, setWatchlist] = useState<string[]>(() => loadLocal<string[]>(WATCHLIST_KEY, []));

  useEffect(() => saveLocal(WATCHLIST_KEY, watchlist), [watchlist]);

  const toggleWatch = (id: string) => {
    setWatchlist((current) =>
      current.includes(id) ? current.filter((coinId) => coinId !== id) : [...current, id],
    );
  };

  return { watchlist, toggleWatch };
}
