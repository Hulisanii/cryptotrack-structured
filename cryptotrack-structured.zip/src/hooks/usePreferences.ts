import { useEffect, useState } from "react";
import type { NotificationSettings, ThemeName } from "../types";
import { loadLocal, saveLocal } from "../utils/storage";

export function usePreferences() {
  const [theme, setTheme] = useState<ThemeName>(() => loadLocal<ThemeName>("crypto_theme", "dark"));
  const [notifications, setNotifications] = useState<NotificationSettings>(() =>
    loadLocal<NotificationSettings>("crypto_notif", { price: true, news: false }),
  );

  useEffect(() => saveLocal("crypto_theme", theme), [theme]);
  useEffect(() => saveLocal("crypto_notif", notifications), [notifications]);

  return { theme, setTheme, notifications, setNotifications };
}
