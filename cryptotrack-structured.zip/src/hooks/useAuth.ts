import { useEffect, useState } from "react";
import type { AuthForm, AuthMode, User } from "../types";
import { loadLocal, saveLocal } from "../utils/storage";

const USER_KEY = "crypto_user";

export function useAuth() {
  const [authMode, setAuthMode] = useState<AuthMode>("landing");
  const [user, setUser] = useState<User | null>(() => loadLocal<User | null>(USER_KEY, null));
  const [authForm, setAuthForm] = useState<AuthForm>({ username: "", email: "", password: "" });
  const [authError, setAuthError] = useState("");

  useEffect(() => {
    if (user) setAuthMode("app");
  }, [user]);

  const clearError = () => setAuthError("");

  const signup = () => {
    if (!authForm.username.trim() || !authForm.email.trim() || !authForm.password.trim()) {
      setAuthError("All fields are required.");
      return;
    }
    if (authForm.password.length < 6) {
      setAuthError("Password must be at least 6 characters.");
      return;
    }

    const userData: User = {
      username: authForm.username,
      email: authForm.email,
      createdAt: Date.now(),
    };
    saveLocal(USER_KEY, userData);
    setUser(userData);
    setAuthMode("app");
    clearError();
  };

  const login = () => {
    const stored = loadLocal<User | null>(USER_KEY, null);
    if (!stored) {
      setAuthError("No account found. Please sign up.");
      return;
    }
    if (authForm.email !== stored.email) {
      setAuthError("Email not found.");
      return;
    }
    setUser(stored);
    setAuthMode("app");
    clearError();
  };

  const guestLogin = () => {
    setUser({ username: "Guest", email: "", createdAt: Date.now(), guest: true });
    setAuthMode("app");
  };

  const logout = () => {
    setUser(null);
    saveLocal(USER_KEY, null);
    setAuthMode("landing");
  };

  return {
    authMode,
    setAuthMode,
    user,
    authForm,
    setAuthForm,
    authError,
    signup,
    login,
    guestLogin,
    logout,
    clearError,
  };
}
