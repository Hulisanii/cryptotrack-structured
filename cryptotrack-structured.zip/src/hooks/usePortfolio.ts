import { useEffect, useMemo, useState } from "react";
import type { AddPortfolioForm, Coin, PortfolioEntry, PortfolioStats } from "../types";
import { loadLocal, saveLocal } from "../utils/storage";

const PORTFOLIO_KEY = "crypto_portfolio";

export function usePortfolio(coins: Coin[]) {
  const [portfolio, setPortfolio] = useState<PortfolioEntry[]>(() => loadLocal<PortfolioEntry[]>(PORTFOLIO_KEY, []));
  const [form, setForm] = useState<AddPortfolioForm>({ coinId: "", amount: "", buyPrice: "" });

  useEffect(() => saveLocal(PORTFOLIO_KEY, portfolio), [portfolio]);

  const stats = useMemo<PortfolioStats[]>(
    () =>
      portfolio.map((entry) => {
        const coin = coins.find((item) => item.id === entry.coinId);
        const currentPrice = coin?.current_price || 0;
        const value = entry.amount * currentPrice;
        const cost = entry.amount * entry.buyPrice;
        const pnl = value - cost;
        const pnlPct = cost > 0 ? (pnl / cost) * 100 : 0;
        return { ...entry, coin, currentPrice, value, cost, pnl, pnlPct };
      }),
    [coins, portfolio],
  );

  const totalValue = stats.reduce((sum, entry) => sum + entry.value, 0);
  const totalCost = stats.reduce((sum, entry) => sum + entry.cost, 0);
  const totalPnl = totalValue - totalCost;

  const addPosition = () => {
    if (!form.coinId || !form.amount || !form.buyPrice) return;
    const entry: PortfolioEntry = {
      id: Date.now(),
      coinId: form.coinId,
      amount: Number.parseFloat(form.amount),
      buyPrice: Number.parseFloat(form.buyPrice),
    };
    setPortfolio((current) => [...current, entry]);
    setForm({ coinId: "", amount: "", buyPrice: "" });
  };

  const removePosition = (id: number) => {
    setPortfolio((current) => current.filter((entry) => entry.id !== id));
  };

  return {
    portfolio,
    form,
    setForm,
    stats,
    totalValue,
    totalCost,
    totalPnl,
    addPosition,
    removePosition,
  };
}
