import { useCallback, useEffect, useRef, useState } from "react";
import { REFRESH_INTERVAL } from "../constants/app";
import { fetchTopCoins } from "../services/cryptoApi";
import type { Coin } from "../types";

export function useCryptoData(enabled: boolean) {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async () => {
    try {
      setError(null);
      const data = await fetchTopCoins();
      setCoins(data);
      setLastUpdated(Date.now());
    } catch {
      setError("Failed to fetch live data. Retrying shortly.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    refresh();
    timerRef.current = setInterval(refresh, REFRESH_INTERVAL);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [enabled, refresh]);

  return { coins, loading, lastUpdated, error, refresh };
}
